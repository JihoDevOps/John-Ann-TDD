module.exports = {
    testEnvironment: "node"
}